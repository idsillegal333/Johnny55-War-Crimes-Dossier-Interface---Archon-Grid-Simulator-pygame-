TE-925 TRUTH ENGINE v7.5564
Johnny55 #BCCRSS Truth Protocol
Omega Override

Type this into the command terminal once the truth engine opens up.
show_bccrss


