import os

# 1. Define the exact paths based on your username
user_home = os.path.expanduser("~")
folder_path = os.path.join(user_home, "truth_engine/truth_engineV64/V3truthengine")

# YOUR WORKING FILE NAME
bin_name = "truth_engine_v76"
icon_name = "icon_linux.png"

bin_full_path = os.path.join(folder_path, bin_name + ".bin")
icon_full_path = os.path.join(folder_path, icon_name)
shortcut_path = os.path.join(user_home, ".local/share/applications/truthengine76.desktop")

# 2. Create the Desktop Entry content
content = f"""[Desktop Entry]
Version=1.0
Type=Application
Name=Truth Engine v76
Comment=Truth Engine Simulator
Exec={bin_full_path}
Path={folder_path}
Icon={icon_full_path}
Terminal=false
StartupNotify=true
Categories=Game;
"""

# 3. Write the file directly to the System Menu folder
with open(shortcut_path, "w") as f:
    f.write(content)

print(f"✅ Shortcut updated!")
print(f"   It is now pointing to: {bin_full_path}")
